package com.example.sandbox.util.constans;

public class TestData {
    public static final String HYDRAIMAGE = "https://gods-and-demons.fandom.com/wiki/Lernaean_Hydra?file=Venture_the_fog_hydra_by_darkcloud013_dbpdkjn-fullview.jpg";
}
