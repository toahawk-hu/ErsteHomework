package com.example.sandbox.util;

public class Tools {
    public static int generateRandomNumber(){
        return (int) (Math.random()*100);
    }
}
